﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BST
{
    public class BinarySearchTree<T> where T : IComparable
    {
        public int Count { get; set; } = 0;
        //public int Height { get; set; } = 0;

        private BSTNode<T> root = null;

        public void Add(T value)
        {
           if(root != null)
            {
                root.Insert(value);
                Count++;
            }
            else
            {
                root = new BSTNode<T>(value);
                Count++;
            }

            
        }

        public bool Contains(T value)
        {
            if(root != null)
            {
                return root.Contains(value);
            }
            else
            {
                return false;
            }

            
        }

        public void Remove(T value)
        {
            //Set current and parent node to root, use parents reference to remove
            BSTNode<T> current = root;
            BSTNode<T> parent = root;

            //Keeps track of which child of parent should be removed
            bool isLeftChild = false;

            //Check for empty tree
            if (current == null)
            {
                return;
            }

            //Find the node by looping
            while(current != null && current.Data.CompareTo(value) != 0)
            {
                //set current node to new parent reference, then look at it's children
                parent = current;

                //if the data is less than current node look at it's left child
                if(value.CompareTo(current.Data) < 0)
                {
                    current = current.Left;
                    isLeftChild = true;
                }
                //else look at it's right child
                else
                {
                    current = current.Right;
                    isLeftChild = false;
                }
            }

            //if node isn't found
            if(current == null)
            {
                return;
            }

            //Check for leaf node (no children)
            if(current.Right == null && current.Left == null)
            {
                //Root doesn't have parent to check what child it is, so just set to null
                if(current == root)
                {
                    root = null;
                }
                else
                {
                    //When not the root node, see which child of parent should be deleted
                    if(isLeftChild)
                    {
                        //remove reference to left child node
                        parent.Left = null;
                    }
                    else
                    {
                        //remove reference to right child node
                        parent.Right = null;
                    }
                }
            }
            //current only has one left child, set parents node child to be this nodes left child
            else if(current.Right == null)
            {
                //if current node is the root, set root to left child
                if(current == root)
                {
                    root = current.Left;
                }
                else
                {
                    //see which child of parent should be deleted
                    if(isLeftChild)
                    {
                        //current is left child so we set left node of parent to current nodes left child
                        parent.Left = current.Left;
                    }
                    else
                    {
                        //current is right child so we set right node of parent to current nodes left child
                        parent.Right = current.Left;
                    }
                }
            }
            //current only has one right child, set parents node child to be this nodes right child
            else if (current.Left == null)
            {
                //if current node is the root, set root to right child
                if(current == root)
                {
                    root = current.Right;
                }
                else
                {
                    //see which child of parent should be deleted
                    if(isLeftChild)
                    {
                        //current is left child, set left node of parent to current nodes right child
                        parent.Left = current.Right;
                    }
                    else
                    {
                        //current is right child, set right node of parent to current nodes right child
                        parent.Right = current.Right;
                    }
                }
            }
            //Current node has both left and right child
            else
            {
                //Find successor node aka least greater node
                BSTNode<T> successor = GetSuccessor(current);

                //if the current node is the root node then the new root is the successor node
                if(current == root)
                {
                    root = successor;
                }
                //if this is the left child, set parents left child as successor node
                else if(isLeftChild)
                {
                    parent.Left = successor;
                }
                //if this is the right child, set parents right child as successor node
                else
                {
                    parent.Right = successor;
                }
            }

            Count--;
        }
            
        private BSTNode<T> GetSuccessor(BSTNode<T> node)
        {
            BSTNode<T> parentOfSuccessor = node;
            BSTNode<T> successor = node;
            BSTNode<T> current = node.Right;

            //starting at right child we go down every left child node
            while (current != null)
            {
                parentOfSuccessor = successor;
                successor = current;

                //go to next left node
                current = current.Left;
            }
            //if successor is not just the right node
            if(successor != node.Right)
            {
                //set left node on parent node of successor node to the right child node of successor in case it has one
                parentOfSuccessor.Left = successor.Right;

                //attach right child node of node being deleted to successors right node
                successor.Right = node.Right;
            }
            //attach left child node of node being deleted to the successors left node
            successor.Left = node.Left;

            return successor;
        }

        public int Height()
        {
            if(root == null)
            {
                return 0;
            }

            return root.Height();
        }

        public void Clear()
        {
            root = null;
            Count = 0;
        }

        public string InOrder()
        {
           if(root != null)
            {
                return root.InOrder().Remove(root.InOrder().Length - 1, 1).TrimStart();
            }

            return "No elements present";
        }

       

        public string PreOrder()
        {
            if(root != null)
            {
                return root.PreOrder().Remove(root.PreOrder().Length - 2, 1).TrimEnd();
            }

            return "No elements present";
        }

        public string PostOrder()
        {
            if(root != null)
            {
                return root.PostOrder().Remove(0, 1).TrimStart();
            }

            return "No elements present";
        }

        public T[] ToArray()
        {
            T[] array = new T[Count];

            InOrder(root, array, 0);

            return array;
        }

        public void InOrder(BSTNode<T> node, T[] arr, int index)
        {
            if(node == null)
            {
                return;
            }

            InOrder(node.Left, arr, index);
            arr[index++] = node.Data;
            InOrder(node.Right, arr, index);
        }
    }
}
