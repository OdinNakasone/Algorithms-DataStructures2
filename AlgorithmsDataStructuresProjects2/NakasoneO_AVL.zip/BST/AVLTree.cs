﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BST
{
    public class AVLTree<T> where T : IComparable
    {
        public int Count { get; set; } = 0;
        //public int Height { get; set; } = 0;

        private AVLNode<T> root = null;

        public void Add(T data)
        {
            AVLNode<T> newNode = new AVLNode<T>(data);
            if(root == null)
            {
                root = newNode;
                Count++;
            }
            else
            {
                root = Insert(root, newNode);
                Count++;
            }
        }

        private AVLNode<T> Insert(AVLNode<T> current, AVLNode<T> node)
        {
            if(current == null)
            {
                current = node;
                
                return current;
            }
            else if(node.Data.CompareTo(current.Data) < 0)
            {
                current.Left = Insert(current.Left, node);
                
                current = BalanceAVLTree(current);
            }
            else if(node.Data.CompareTo(current.Data) > 0)
            {
                current.Right = Insert(current.Right, node);
               
                current = BalanceAVLTree(current);
            }

            

            return current;
        }

        private AVLNode<T> BalanceAVLTree(AVLNode<T> current)
        {
            int bf = BalanceFactor(current);

            if(bf > 1)
            {
                if(BalanceFactor(current.Left) > 0)
                {
                    current = RotateSingleLeft(current);
                }
                else
                {
                    current = RotateLeftRight(current);
                }
            }
            else if(bf < -1)
            {
                if(BalanceFactor(current.Right) > 0)
                {
                    current = RotateRightLeft(current);
                }
                else
                {
                    current = RotateSingleRight(current);
                }
            }

            return current;
        }

        public bool Contains(T value)
        {
            if(Contains(value, root).Data.CompareTo(value) == 0)
            {
                return true;
            }
            else
            {
                return false;
            }


        }

        private AVLNode<T> Contains(T value, AVLNode<T> current)
        {
            if(value.CompareTo(current.Data) < 0)
            {
                if(value.CompareTo(current.Data) == 0)
                {
                    return current;
                }
                else
                {
                    return Contains(value, current.Left);
                }
            }
            else
            {
                if(value.CompareTo(current.Data) == 0)
                {
                    return current;
                }
                else
                {
                    return Contains(value, current.Right);
                }
            }
        }

        public void Remove(T value)
        {
            root = Remove(root, value);
            Count--;
        }

        private AVLNode<T> Remove(AVLNode<T> current, T value)
        {
            AVLNode<T> parent;

            if(current == null)
            {
                return null;
            }
            else
            {
                if(value.CompareTo(current.Data) < 0)
                {
                    current.Left = Remove(current.Left, value);
                    if(BalanceFactor(current) == -2)
                    {
                        if(BalanceFactor(current.Right) <= 0)
                        {
                            current = RotateSingleRight(current);
                        }
                        else
                        {
                            current = RotateRightLeft(current);
                        }
                    }
                }
                else if(value.CompareTo(current.Data) > 0)
                {
                    current.Right = Remove(current.Right, value);
                    if(BalanceFactor(current) == 2)
                    {
                        if(BalanceFactor(current.Left) >= 0)
                        {
                            current = RotateSingleLeft(current);
                        }
                        else
                        {
                            current = RotateLeftRight(current);
                        }
                    }
                }
                else
                {
                    if(current.Right != null)
                    {
                        parent = current.Right;
                        while(parent.Left != null)
                        {
                            parent = parent.Left;
                        }
                        current.Data = parent.Data;
                        current.Right = Remove(current.Right, parent.Data);

                        if(BalanceFactor(current) == 2)
                        {
                            if(BalanceFactor(current.Left) >= 0)
                            {
                                current = RotateSingleLeft(current);
                            }
                            else
                            {
                                current = RotateLeftRight(current);
                            }
                        }
                    }
                    else
                    {
                        return current.Left;
                    }
                }
            }

            return current;
        }

        private int Max(int num1, int num2)
        {
            return num1 > num2 ? num1 : num2;
        }


        private int Height(AVLNode<T> current)
        {
            int height = 0;
            if(current != null)
            {
                int left = Height(current.Left);
                int right = Height(current.Right);
                int max = Max(left, right);
                height = max + 1;
            }

            return height;
        }

       
        private int BalanceFactor(AVLNode<T> current)
        {
            int left = Height(current.Left);
            int right = Height(current.Right);
            int balanceFactor = left - right;
            return balanceFactor;
        }

        private AVLNode<T> RotateSingleRight(AVLNode<T> parent)
        {
            AVLNode<T> pivot = parent.Right;
            parent.Right = pivot.Left;
            pivot.Left = parent;
            return pivot;
        }

        private AVLNode<T> RotateSingleLeft(AVLNode<T> parent)
        {
            AVLNode<T> pivot = parent.Left;
            parent.Left = pivot.Right;
            pivot.Right = parent;
            return pivot;
        }

        private AVLNode<T> RotateLeftRight(AVLNode<T> parent)
        {
            AVLNode<T> pivot = parent.Left;
            parent.Left = RotateSingleRight(pivot);
            return RotateSingleLeft(parent);
        }

        private AVLNode<T> RotateRightLeft(AVLNode<T> parent)
        {
            AVLNode<T> pivot = parent.Right;
            parent.Right = RotateSingleLeft(pivot);
            return RotateSingleRight(parent);
        }
        public void Clear()
        {
            root = null;
            Count = 0;
        }

        //public string InOrder()
        //{
        //    if (root != null)
        //    {
        //        return root.InOrder().Remove(root.InOrder().Length - 1, 1).TrimStart();
        //    }

        //    return "No elements present";
        //}

        //public string PreOrder()
        //{
        //    if (root != null)
        //    {
        //        return root.PreOrder().Remove(root.PreOrder().Length - 2, 1).TrimEnd();
        //    }

        //    return "No elements present";
        //}

        //public string PostOrder()
        //{
        //    if (root != null)
        //    {
        //        return root.PostOrder().Remove(0, 1).TrimStart();
        //    }

        //    return "No elements present";
        //}

        public T[] ToArray()
        {
            List<T> tempValues = new List<T>();
            Queue<AVLNode<T>> queue = new Queue<AVLNode<T>>();
            queue.Enqueue(root);

            while(queue.Count != 0)
            {
                var temp = queue.Dequeue();
                tempValues.Add(temp.Data);

                if(temp.Left != null)
                {
                    queue.Enqueue(temp.Left);
                }

                if(temp.Right != null)
                {
                    queue.Enqueue(temp.Right);
                }

               
            }

            return tempValues.ToArray();
        }

        private void InOrder(AVLNode<T> node, T[] arr, int index)
        {
            if (node == null)
            {
                return;
            }

            InOrder(node.Left, arr, index);
            arr[index++] = node.Data;
            InOrder(node.Right, arr, index);
        }
    }
}
