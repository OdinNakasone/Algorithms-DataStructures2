﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using AlgoDataStructures;
using System;
using System.Collections.Generic;
using System.Text;

namespace AlgoTests
{
    [TestClass]
    public class LinkedListTests
    {
        [TestMethod]
        public void SingleLinkedListAddTest()
        {
            SingleLinkedList<int> sll = new SingleLinkedList<int>();

            sll.Add(19);
            sll.Add(21);

            LinkedList<int> testList = new LinkedList<int>();
            testList.AddLast(19);
            testList.AddLast(21);

            Assert.AreEqual(testList.First.Value, sll.Get(0));
            //Assert.ThrowsException<IndexOutOfRangeException>(() => { sll.Get(2); });
        }

        [TestMethod]
        public void SingleLinkedClear()
        {
            SingleLinkedList<string> sll = new SingleLinkedList<string>();
            sll.Add("hi");
            sll.Add("we");
            sll.Add("cool");

            sll.Clear();

            Assert.AreEqual(0, sll.Count);
            
        }

        [TestMethod]
        public void SingleLinkedListGetTest()
        {
            SingleLinkedList<int> sll = new SingleLinkedList<int>();
            sll.Add(12);
            sll.Add(21);
            sll.Add(323);

            int testValue = sll.Get(2);
            int testValue2 = sll.Get(0);

            Assert.AreEqual(323, testValue);
            Assert.AreNotEqual(323, testValue2);
        }

        [TestMethod]
        public void SingleLinkedListInsertAtTest()
        {
            SingleLinkedList<int> sll = new SingleLinkedList<int>();
            sll.Add(12);
            sll.Add(22);
            sll.Add(32);
            sll.Insert(100, 2);

            int testValue = sll.Get(2);
            Assert.AreEqual(100, testValue);

        }

        [TestMethod]
        public void SingleLinkedListRemoveTest()
        {
            SingleLinkedList<int> sll = new SingleLinkedList<int>();
            sll.Add(1);
            sll.Add(2);
            sll.Add(3);

            sll.Remove();

            Assert.AreEqual(2, sll.Get(0));
            Assert.AreEqual(2, sll.Count);
            Assert.ThrowsException<IndexOutOfRangeException>(() => { sll.Get(2); });
        }

        [TestMethod]
        public void SingleLinkedListRemoveLastTest()
        {
            SingleLinkedList<int> sll = new SingleLinkedList<int>();
            sll.Add(1);
            sll.Add(2);
            sll.Add(3);

            sll.RemoveLast();

            Assert.AreEqual(2, sll.Get(1));
            Assert.AreEqual(2, sll.Count);
            Assert.ThrowsException<IndexOutOfRangeException>(() => { sll.Get(2); });
        }
        
        [TestMethod]
        public void SingleLinkedListSearchTest()
        {
            SingleLinkedList<int> sll = new SingleLinkedList<int>();
            sll.Add(1);
            sll.Add(2);
            sll.Add(3);

            Assert.AreEqual(2, sll.Search(3));
        }

        [TestMethod]
        public void SingleLinkedListRemoveAtTest()
        {
            SingleLinkedList<int> sll = new SingleLinkedList<int>();
            sll.Add(1);
            sll.Add(2);
            sll.Add(3);

            Assert.AreEqual(3, sll.RemoveAt(2));
            Assert.AreEqual(2, sll.Count);
            Assert.ThrowsException<IndexOutOfRangeException>(() => { sll.Get(2); });
        }

        [TestMethod]
        public void SingleLinkedListToStringTest()
        {
            SingleLinkedList<int> sll = new SingleLinkedList<int>();
            sll.Add(1);
            sll.Add(2);
            sll.Add(3);

            string test = sll.ToString();

            Assert.AreEqual("1, 2, 3", test);
            
        }

        [TestMethod]
        public void SingleLinkedListEmptyToStringTest()
        {
            SingleLinkedList<int> sll = new SingleLinkedList<int>();
            

            string test = sll.ToString();

            Assert.AreEqual("No Elements Found", test);

        }

        [TestMethod]
        public void DoubleLinkedListAddTest()
        {
            DoubleLinkedList<int> dll = new DoubleLinkedList<int>();
            dll.Add(1);
            dll.Add(2);
            dll.Add(3);

            Assert.AreEqual(2, dll.Get(1));
            Assert.AreEqual(3, dll.Count);
        }

        [TestMethod]
        public void DoubleLinkedListInsertTest()
        {
            DoubleLinkedList<int> dll = new DoubleLinkedList<int>();
            dll.Add(1);
            dll.Add(4);
            dll.Add(76);
            dll.Add(21);

            dll.Insert(23, 2);

            Assert.AreEqual(23, dll.Get(2));
        }

        [TestMethod]
        public void DoubleLinkedListRemoveTest()
        {
            DoubleLinkedList<int> dll = new DoubleLinkedList<int>();
            dll.Add(1);
            dll.Add(2);
            dll.Add(3);

            dll.Remove();

            Assert.AreEqual(2, dll.Get(0));
            Assert.AreEqual(2, dll.Count);
        }

        [TestMethod]
        public void DoubleLinkedListRemoveAtTest()
        {
            DoubleLinkedList<int> dll = new DoubleLinkedList<int>();
            dll.Add(1);
            dll.Add(2);
            dll.Add(3);

            int test = dll.RemoveAt(1);

            Assert.AreEqual(2, test);
            Assert.AreEqual(2, dll.Count);
            
        }

        [TestMethod]
        public void DoubleLinkedListRemoveLast()
        {
            DoubleLinkedList<int> dll = new DoubleLinkedList<int>();
            dll.Add(1);
            dll.Add(2);
            dll.Add(3);
            dll.Add(43);

           
            Assert.AreEqual(43, dll.RemoveLast());
            Assert.AreEqual(3, dll.Count);
        }

        [TestMethod]
        public void DoubleLinkedListClearTest()
        {
            DoubleLinkedList<string> dll = new DoubleLinkedList<string>();
            dll.Add("hello");
            dll.Add("you");
            dll.Add("good");

            dll.Clear();

            Assert.AreEqual(0, dll.Count);

        }

        [TestMethod]
        public void DoubleLinkedListSearchTest()
        {
            DoubleLinkedList<int> dll = new DoubleLinkedList<int>();
            dll.Add(21);
            dll.Add(23);
            dll.Add(41);

            Assert.AreEqual(2, dll.Search(41));
            Assert.AreEqual(-1, dll.Search(4));
        }

        [TestMethod]
        public void DoubleLinkedListToStringTest()
        {
            DoubleLinkedList<int> dll = new DoubleLinkedList<int>();
            dll.Add(21);
            dll.Add(23);
            dll.Add(41);

            Assert.AreEqual("21, 23, 41", dll.ToString());
            
        }

        [TestMethod]
        public void DoubleLinkedListToStringEmptyTest()
        {
            DoubleLinkedList<int> dll = new DoubleLinkedList<int>();
            dll.Add(21);
            dll.Add(23);
            dll.Add(41);

            dll.Clear();

            Assert.AreEqual("No Elements Found", dll.ToString());
            
        }
    }
}
