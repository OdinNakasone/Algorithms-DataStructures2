using Akka.Actor.Setup;
using NUnit.Framework;

namespace MyAlgoTests
{
    public class Tests
    {
        [Setup]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            Assert.Pass();
        }
    }
}