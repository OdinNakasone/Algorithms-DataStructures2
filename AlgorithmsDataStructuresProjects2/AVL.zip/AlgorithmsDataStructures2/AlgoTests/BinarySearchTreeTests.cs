﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using BST;
using System.Collections.Generic;
using System.Text;

namespace AlgoTests
{
    [TestClass]
    public class BinarySearchTreeTests
    {
        [TestMethod]
        public void BinarySearchTreeCountTest()
        {
            int testCount = 8;
            BinarySearchTree<int> bst = new BinarySearchTree<int>();

            for(int i = 0; i < testCount; i++)
            {
                bst.Add(i);
            }

            Assert.AreEqual(testCount, bst.Count);
        }

        [TestMethod]
        public void BinarySearchTreeAddTest()
        {
            BinarySearchTree<int> bst = new BinarySearchTree<int>();
            bst.Add(50);
            bst.Add(2);
            bst.Add(100);

            Assert.AreEqual(3, bst.Count);        
        }

        [TestMethod]
        public void BinarySearchTreeContainsTest()
        {
            BinarySearchTree<int> bst = new BinarySearchTree<int>();
            bst.Add(50);
            bst.Add(2);
            bst.Add(100);
            bst.Add(32);
            bst.Add(5);

            Assert.AreEqual(true, bst.Contains(100));
            Assert.AreEqual(false, bst.Contains(132));
        }

        [TestMethod]
        public void BinarySearchTreeRemoveTest()
        {
            BinarySearchTree<int> bst = new BinarySearchTree<int>();
            bst.Add(50);
            bst.Add(2);
            bst.Add(100);
            bst.Add(32);
            bst.Add(5);

            bst.Remove(5);
            bst.Remove(100);

            Assert.AreEqual(false, bst.Contains(5));
            Assert.AreEqual(false, bst.Contains(100));
            Assert.AreEqual(true, bst.Contains(50));
        }

        [TestMethod]
        public void BinarySearchTreeHeightTest()
        {
            BinarySearchTree<int> bst = new BinarySearchTree<int>();
            bst.Add(10);
            bst.Add(7);
            bst.Add(12);
            bst.Add(11);
            bst.Add(3);
            bst.Add(8);

            Assert.AreEqual(3, bst.Height());
        }

        [TestMethod]
        public void BinarySearchTreeInOrderTest()
        {
            BinarySearchTree<int> bst = new BinarySearchTree<int>();
            bst.Add(50);
            bst.Add(2);
            bst.Add(100);
            bst.Add(32);
            bst.Add(5);

            Assert.AreEqual("2, 5, 32, 50, 100", bst.InOrder());
        }

        [TestMethod]
        public void BinarySearchTreeClearTest()
        {
            BinarySearchTree<int> bst = new BinarySearchTree<int>();
            bst.Add(50);
            bst.Add(2);
            bst.Add(100);
            bst.Add(32);
            bst.Add(5);

            bst.Clear();

            Assert.AreEqual("No elements present", bst.InOrder());
        }

        [TestMethod]
        public void BinarySearchTreePreOrderTest()
        {
            BinarySearchTree<int> bst = new BinarySearchTree<int>();
            bst.Add(10);
            bst.Add(7);
            bst.Add(12);
            bst.Add(11);
            bst.Add(3);
            bst.Add(8);

            Assert.AreEqual("10, 7, 3, 8, 12, 11", bst.PreOrder());
        }

        [TestMethod]
        public void BinarySearchTreePostOrderTest()
        {
            BinarySearchTree<int> bst = new BinarySearchTree<int>();
            bst.Add(10);
            bst.Add(7);
            bst.Add(12);
            bst.Add(11);
            bst.Add(3);
            bst.Add(8);

            Assert.AreEqual("3, 8, 7, 11, 12, 10", bst.PostOrder());
        }

        [TestMethod]
        public void BinarySearchTreeToArrayTest()
        {
            BinarySearchTree<int> bst = new BinarySearchTree<int>();
            bst.Add(10);
            bst.Add(7);
            bst.Add(12);
            bst.Add(11);
            bst.Add(3);
            bst.Add(8);

            int[] test = new int[] {3, 7, 8, 10, 11, 12 };
            Assert.AreEqual(test.ToString(), bst.ToArray().ToString());
        }
    }
}
