﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AlgoDataStructures
{
    public class DoubleLinkedList<T> where T : IComparable
    {
        public int Count { get; set; } = 0;

        private DoubleNode<T> start = null;
        private DoubleNode<T> tail = null;

        public void Add(T val)
        {
            DoubleNode<T> newNode = new DoubleNode<T>(val);

            if(start == null)
            {
                start = newNode;
                tail = newNode;

                start.Previous = null;
                tail.Next = null;
            }
            else
            {
                tail.Next = newNode;
                newNode.Previous = tail;
                tail = newNode;
                tail.Next = null;
            }

            Count++;
        }

        public void Insert(T val, int index)
        {
            DoubleNode<T> temp = start;
            DoubleNode<T> newNode = new DoubleNode<T>(val);

            if(temp == null || Count < index)
            {
                return;
            }
            else
            {
                newNode.Data = val;

                for(int i = 0; i < index - 1; i++)
                {
                    temp = temp.Next;
                }

                newNode.Next = temp.Next;
                temp.Next.Previous = newNode;
                temp.Next = newNode;
                newNode.Previous = temp;
            }

            Count++;
        }

        public T Get(int index)
        {
            if (index < 0 || index >= Count)
            {
                throw new IndexOutOfRangeException();
            }

            DoubleNode<T> current = start;
            int counter = 0;

            while (current != null)
            {
                if (counter == index)
                {
                    return current.Data;
                }

                counter++;
                current = current.Next;
            }
            return current.Data;
        }

        public T Remove()
        {
            if (start == null)
            {
                return default;
            }
            else
            {
                if(start != tail)
                {
                    start = start.Next;
                    start.Previous = null;
                }
                else
                {
                    start = null; 
                    tail = null;
                }
            }

            Count--;

            return start.Data;
        }

        public T RemoveAt(int index)
        {
            if(start == null)
            {
                return default;
            }

            if (index < 0 || index >= Count)
            {
                throw new IndexOutOfRangeException();
            }

            DoubleNode<T> current = start;
            int i;

            for(i = 1; current != null && i < index; i++)
            {
                current = current.Next;
            }

            if(current == null)
            {
                return default;
            }

            Count--;

            return DeleteNode(start, current).Data;
        }

        public T RemoveLast()
        {
            DoubleNode<T> temp = tail;

           if(start == null)
            {
                return default;
            }
            else
            {
                if(start != tail)
                {
                    temp.Next = null;
                }
                else
                {
                    start = temp = null;
                }
            }

            Count--;

            return temp.Data;
        }

        public void Clear()
        {
            start = null;
            tail = null;
            Count = 0;
        }

        public int Search(T val)
        {
            DoubleNode<T> current = start;
            int counter = 0;

            while(current != null)
            {
                if(current.Data.CompareTo(val) == 0)
                {
                    return counter;
                }
                current = current.Next;
                counter++;
            }

            return -1;
        }

        private DoubleNode<T> DeleteNode(DoubleNode<T> head, DoubleNode<T> del)
        {
            if (head == null || del == null)
            {
                return default;
            }

            if(head == del)
            {
                head = del.Next;
            }

            if(del.Next != null)
            {
                del.Next.Previous = del.Previous;
            }

            if(del.Previous != null)
            {
                del.Previous.Next = del.Next;
            }

            del = null;

            return head;
        }

        public override string ToString()
        {
            string message;
            List<T> values = new List<T>();


            DoubleNode<T> current = start;

            while (current != null)
            {
                values.Add(current.Data);
                current = current.Next;
            }
            if (values.Count == 0)
            {
                message = "No Elements Found";
            }
            else
            {
                message = String.Join(", ", values.Select(x => x.ToString()).ToArray());
            }


            return message;
        }
    }
}
