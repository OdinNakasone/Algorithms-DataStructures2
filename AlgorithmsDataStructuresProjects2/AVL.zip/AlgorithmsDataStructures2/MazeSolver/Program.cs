﻿using System;
using System.IO;
using System.Collections.Generic;

namespace MazeSolver
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter path to file");
            var path = Console.ReadLine();

            var result = File.ReadAllLines(path);

            foreach(var line in result)
            {

            }
        }
    }
}
