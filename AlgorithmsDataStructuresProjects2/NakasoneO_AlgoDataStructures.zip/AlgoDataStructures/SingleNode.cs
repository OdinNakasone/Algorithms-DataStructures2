﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlgoDataStructures
{
   public class SingleNode<T>
    {
        public T Data;
        public SingleNode<T> Next;

      public SingleNode(T d)
        {
            Data = d;
            Next = null;
        }

      public SingleNode()
        {

        }
    }
}
