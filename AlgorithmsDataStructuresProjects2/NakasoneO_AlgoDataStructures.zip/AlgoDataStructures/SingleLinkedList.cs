﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace AlgoDataStructures
{
    public class SingleLinkedList<T> where T : IComparable
    {
        public int Count { get; set; } = 0;

        private SingleNode<T> head;
        private SingleNode<T> tail;
        

        public void Add(T val)
        {
            SingleNode<T> newNode = new SingleNode<T>(val);
            newNode.Next = null;

            if(head == null)
            {
                head = newNode;
            }
            else
            {
                tail.Next = newNode;
            }
            tail = newNode;
            Count++;
            
        }

        public void Insert(T val, int index)
        {
            SingleNode<T> node = new SingleNode<T>(val);
            node.Next = null;

            if(head == null)
            {
                if(index != 0)
                {
                    return;
                }
                else
                {
                    head = node;
                }
            }

            if (head != null && index == 0)
            {
                node.Next = head;
                head = node;
                return;
            }

            SingleNode<T> current = head;
            SingleNode<T> previous = null;

            int i = 0;

            while(i < index)
            {
                previous = current;
                current = current.Next;

                if(current == null)
                {
                    break;
                }

                i++;
            }

            node.Next = current;
            previous.Next = node;
        }

        public T Get(int index)
        {
           if(index < 0 || index >= Count)
            {
                throw new IndexOutOfRangeException();
            }

            SingleNode<T> current = head;
            int counter = 0;

            while(current != null)
            {
                if(counter == index)
                {
                    return current.Data;
                }

                counter++;
                current = current.Next;
            }
            return current.Data;
        }

        public T Remove()
        {
            if(head == null)
            {
                return default;
            }

            SingleNode<T> temp = head;
            head = head.Next;
            Count--;

            return temp.Data;
            
        }

        public T RemoveAt(int index)
        {

            if (index < 0 || index >= Count)
            {
                throw new IndexOutOfRangeException();
            }

            if (head == null) return default;

            SingleNode<T> temp = head;

            if(index == 0)
            {
                head = temp.Next;
                return default;
            }

            for(int i = 0; temp != null && i < index - 1; i++)
            {
                temp = temp.Next;
            }

            if (temp == null || temp.Next == null) return default;

            SingleNode<T> next = temp.Next;
            temp.Next = next;
            Count--;

            return next.Data;
        }

        public T RemoveLast()
        {
            if(head == null)
            {
                return default;
            }

            if(head.Next== null)
            {
                return default;
            }

            SingleNode<T> secondToLast = head;
            while(secondToLast.Next.Next != null)
            {
                secondToLast = secondToLast.Next;
            }
            secondToLast.Next = null;
            Count--;

            return secondToLast.Data;
        }

        public void Clear()
        {
            head = null;
            Count = 0;
        }

        public int Search(T val)
        {
            SingleNode<T> current = head;
            int counter = 0;

            while (current != null)
            {
                
                if (current.Data.CompareTo(val) == 0)
                {
                    return counter;
                }
                current = current.Next;
                counter++;
            }     
            return -1;
        }

        public override string ToString()
        {
            string message;
            List<T> values = new List<T>();
            
            
            SingleNode<T> current = head;

            while(current != null)
            {
                values.Add(current.Data);
                current = current.Next;
            }
            if(values.Count == 0)
            {
                message = "No Elements Found";
            }
            else
            {
                message = String.Join(", ", values.Select(x => x.ToString()).ToArray());
            }

          
            return message;
        }
    }
}
