﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AlgoDataStructures
{
    class DoubleNode<T>
    {
        public T Data;
        public DoubleNode<T> Next;
        public DoubleNode<T> Previous;

        public DoubleNode(T d)
        {
            Data = d;
            Next = null;
            Previous = null;
        }

        public DoubleNode()
        {

        }
    }
}
