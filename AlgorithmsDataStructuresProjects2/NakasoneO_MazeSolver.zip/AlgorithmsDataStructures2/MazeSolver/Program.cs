﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace MazeSolver
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter path to file");
            //Test path: C:\Neumont Year 2\Q3\Algorithms & Data Structures 2\AlgorithmsDataStructures2\MazeSolver\TestMazes.txt

            string path = Console.ReadLine();

            if(path != null)
            {
                string[] result = File.ReadAllLines(path);

                List<string[]> graphs = new List<string[]>();

                List<string> tList = new List<string>();

                foreach(string line in result)
                {
                    if(line == "")
                    {
                        graphs.Add(tList.ToArray());
                        tList.Clear();
                    }
                    else
                    {
                        tList.Add(line);
                    }
                }

                if(tList.Count > 0)
                {
                    graphs.Add(tList.ToArray());
                    tList.Clear();
                }

                foreach(string[] graph in graphs)
                {
                    Graph<string> g = new Graph<string>();
                    int index = 0;
                    string start = "";
                    string end = "";

                    foreach(string line in graph)
                    {
                        if (index == 0)
                        {
                            string[] vertices = line.Split(',');
                            foreach (string vertex in vertices)
                            {
                                Vertex<string> v = new Vertex<string>(vertex);
                                g.AddVertex(v);
                            }
                        }
                        else if (index == 1)
                        {
                            string[] a = line.Split(',');
                            start = a[0];
                            end = a[1];
                        }
                        else if(index >= 2)
                        {
                            List<string> vertices = line.Split(',').ToList();
                            if(vertices.Count > 0)
                            {
                                string tStart = vertices[0];
                                vertices.RemoveAt(0);

                                foreach(string v in vertices)
                                {
                                    g.AddEdge(tStart, v);
                                }
                            }
                        }

                        index++;
                    }

                    List<Vertex<string>> r = g.GetShortPassage(start, end);
                    if(r != null)
                    {
                        Console.Write("Shortest route from " + start + " to " + end + ": ");

                        foreach(Vertex<string> v in r)
                        {
                            Console.Write(v.Data);
                        }
                    }

                    Console.WriteLine();
                }
            }
        }
    }
}
