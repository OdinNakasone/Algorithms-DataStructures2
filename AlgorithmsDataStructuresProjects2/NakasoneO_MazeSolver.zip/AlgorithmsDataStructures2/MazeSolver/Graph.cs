﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MazeSolver
{
    public class Graph<T> where T : IComparable<T>
    {
        public int Count { get; set; }

        public Dictionary<T, Vertex<T>> VertexList = new Dictionary<T, Vertex<T>>();

        public void AddEdge(T startVertex, T endVertex)
        {
            Vertex<T> start = VertexList[startVertex];
            Vertex<T> end = VertexList[endVertex];
            start.EdgeList.AddLast(end);
        }

        public void AddVertex(Vertex<T> v)
        {
            VertexList[v.Data] = v;
            Count++;
        }

        public List<Vertex<T>> GetShortPassage(T start, T end)
        {
            if (!VertexList.ContainsKey(start) || !VertexList.ContainsKey(end))
            {
                Console.WriteLine("Vertices not found");
                return null;
            }

            if(!BFS(VertexList[start], VertexList[end]))
            {
                Console.WriteLine("Cannot solve the graph");
                return null;
            }

            Queue<Vertex<T>> q = new Queue<Vertex<T>>();
            HashSet<Vertex<T>> shortPassage = new HashSet<Vertex<T>>();

            Dictionary<T, Vertex<T>> seen = new Dictionary<T, Vertex<T>>();
            Dictionary<Vertex<T>, Vertex<T>> prev = new Dictionary<Vertex<T>, Vertex<T>>();

            Vertex<T> startVertex = VertexList[start];
            seen[startVertex.Data] = startVertex;
            q.Enqueue(startVertex);

            while(q.Count != 0)
            {
                Vertex<T> v = q.Dequeue();
                shortPassage.Add(v);

                if(v.Data.CompareTo(VertexList[end].Data) == 0)
                {
                    return GeneratePassage(v, prev);
                }

                foreach(Vertex<T> sibling in v.EdgeList)
                {
                    if(shortPassage.Contains(sibling))
                    {
                        continue;
                    }

                    int distanceTotal = v.Distance;
                    prev[sibling] = v;

                    if(!seen.ContainsKey(sibling.Data))
                    {
                        seen[sibling.Data] = sibling;
                        sibling.Distance = v.Distance + 1;
                        q.Enqueue(sibling);
                    }
                    else if (distanceTotal < sibling.Distance + 1)
                    {
                        sibling.Distance = v.Distance + 1;
                        prev[sibling] = v;

                        q = new Queue<Vertex<T>>(q.Where(i => !i.Data.Equals(sibling.Data)));
                        q.Enqueue(sibling);
                    }
                }
            }

            return null;
        }

        public bool BFS(Vertex<T> start, Vertex<T> end)
        {
            Dictionary<T, bool> seen = new Dictionary<T, bool>();

            Queue<Vertex<T>> q = new Queue<Vertex<T>>();

            seen[start.Data] = true;

            q.Enqueue(start);

            while(q.Count != 0)
            {
                start = q.Dequeue();

                LinkedList<Vertex<T>> adj = start.EdgeList;

                foreach(Vertex<T> v in adj.Where(v => !seen.ContainsKey(v.Data)))
                {
                    seen[v.Data] = true;
                    q.Enqueue(v);

                    if(v.Data.CompareTo(end.Data) == 0)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        public List<Vertex<T>> GeneratePassage(Vertex<T> v, Dictionary<Vertex<T>, Vertex<T>> prev)
        {
            List<Vertex<T>> passage = new List<Vertex<T>>();

            while(v != null)
            {
                passage.Add(v);
                v = prev.ContainsKey(v) ? prev[v] : null;
            }

            passage.Reverse();

            return passage;
        }
    }
}
