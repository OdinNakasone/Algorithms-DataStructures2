﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BST
{
    class AVLNode<T> where T : IComparable
    {
        public T Data;

        public AVLNode<T> Left { get; set; }
        public AVLNode<T> Right { get; set; }

        public AVLNode(T value)
        {
            Data = value;
   
        }

       
    }
}
