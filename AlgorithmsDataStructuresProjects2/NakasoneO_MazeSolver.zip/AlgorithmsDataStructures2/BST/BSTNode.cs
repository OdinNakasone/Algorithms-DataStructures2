﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BST
{
    public class BSTNode<T> where T : IComparable
    {
        public T Data;
        public BSTNode<T> Left { get; set; }
        public BSTNode<T> Right { get; set; }

        public BSTNode(T value)
        {
            Data = value;
        }

        //Recursively calls Insert down the tree until open spot is found
        public void Insert(T value)
        {
            //If value >= to Data, then insert to Right node
            if(value.CompareTo(Data) > 0 || value.CompareTo(Data) == 0)
            {
                //If right node = null, create one
                if(Right == null)
                {
                    Right = new BSTNode<T>(value);
                }
                else
                {
                    //If right node != null, recursively call insert on right node
                    Right.Insert(value);
                }
            }
            //If value < Data, then insert to Left node
            else
            {
                //If left node = null, create one
                if (Left == null)
                {
                    Left = new BSTNode<T>(value);
                }
                else
                {
                    //If right node != null, recursively call insert on right node
                    Left.Insert(value);
                }
            }
        }

        public string InOrder()
        {
            List<T> nodes = new List<T>();
            string leftNode = "";
            string rightNode = "";
            string message = "";

            if(Left != null)
              leftNode += Left.InOrder();

            message += Data + ", ";

            if (Right != null)
               rightNode +=  Right.InOrder();

            
            nodes.Add(Data);

            message = String.Join(", ", nodes.Select(x => x.ToString()).ToArray());




            string final = leftNode + " " + message + "," + rightNode;
          
            return final;
        }

        public string PreOrder()
        {
            List<T> nodes = new List<T>();
            string leftNode = "";
            string rightNode = "";
            string message = "";

            message += Data + ", ";

            if (Left != null)
                leftNode += Left.PreOrder();

            if (Right != null)
                rightNode += Right.PreOrder();

            
            nodes.Add(Data);

            message = String.Join(", ", nodes.Select(x => x.ToString()).ToArray());




            string final = message + ", " + leftNode  + rightNode;
            return final;
        }

        public string PostOrder()
        {
            List<T> nodes = new List<T>();
            string leftNode = "";
            string rightNode = "";
            string message = "";

          

            if (Left != null)
                leftNode += Left.PostOrder();

            if (Right != null)
                rightNode += Right.PostOrder();

            message += Data + ", ";


            nodes.Add(Data);

            message = String.Join(", ", nodes.Select(x => x.ToString()).ToArray());




            string final = leftNode + rightNode + ", " + message;
            return final;
        }

        public bool Contains(T value)
        {
            //Starting current node
            BSTNode<T> currentNode = this;

            //loop through current node and children nodes
            while(currentNode != null)
            {
                //if current value is equal to value passed in return true
                if(value.CompareTo(currentNode.Data) == 0)
                {
                    return true;
                }
                //if the value passed in is greater than cuurent value, go to right child
                else if (value.CompareTo(currentNode.Data) > 0)
                {
                    currentNode = currentNode.Right;
                }
                //else go to left child
                else
                {
                    currentNode = currentNode.Left;
                }
            }

            //Value is not in tree
            return false;
        }

        public int Height()
        {
            //return 1 when leaf node is found
            if(this.Left == null && this.Right == null)
            {
                //found a leaf node
                return 1;
            }

            int left = 0;
            int right = 0;

            //recursively go through each branch
            if (this.Left != null)
                left = this.Left.Height();
            if (this.Right != null)
                right = this.Right.Height();

            if(left > right)
            {
                return (left + 1);
            }
            else
            {
                return (right + 1);
            }
        }
    }
}
